package com.cookandroid.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MypageActivity extends AppCompatActivity {
    Button button2;
    Button button11;
    EditText name, Phone, Email, EmailCrm, Password, PasswordCrm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage);

        Button button2 = (Button) findViewById(R.id.btnBack);
        Button button11 = (Button) findViewById(R.id.button11);
        EditText name = (EditText) findViewById(R.id.name);
        EditText Phone = (EditText) findViewById(R.id.Phone);
        EditText Email = (EditText) findViewById(R.id.Email);
        EditText EmailCrm = (EditText) findViewById(R.id.EmailCrm);
        EditText Password = (EditText) findViewById(R.id.Password);
        EditText PasswordCrm = (EditText) findViewById(R.id.PasswordCrm);


        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(),MyinfoActivity.class);
                startActivity(intent);
            }
        });
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name.setText("");
                Phone.setText("");
                Email.setText("");
                EmailCrm.setText("");
                Password.setText("");
                PasswordCrm.setText("");

            }
        });
    }
}