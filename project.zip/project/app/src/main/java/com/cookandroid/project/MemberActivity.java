package com.cookandroid.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MemberActivity extends AppCompatActivity {
    Button btnRegistor, btnBack, btnReset;
    EditText txtId, txtEmail, txtPw, txtPwc;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member);

        // DBHelper 인스턴스 생성
        dbHelper = new DBHelper(this);

        Button btnRegistor = (Button) findViewById(R.id.btnRegistor);
        Button btnBack = (Button) findViewById(R.id.btnBack);
        Button btnReset = (Button) findViewById(R.id.btnReset);

        EditText txtId = (EditText) findViewById(R.id.txtId);
        EditText txtEmail = (EditText) findViewById(R.id.txtEmail);
        EditText txtPw = (EditText) findViewById(R.id.txtPw);
        EditText txtPwc = (EditText) findViewById(R.id.txtPwc);

        btnRegistor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = txtId.getText().toString().trim();
                String email = txtEmail.getText().toString().trim();
                String password = txtPw.getText().toString().trim();
                String passwordconfirm = txtPwc.getText().toString().trim();

                // 입력 필드가 비어있는지 확인
                if (id.isEmpty() || email.isEmpty() || password.isEmpty() || passwordconfirm.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "모두 입력해주세요!", Toast.LENGTH_SHORT).show();
                } else {
                    // SQLite에 회원 정보 저장
                    dbHelper.insertUser(id, password);

                    // 회원가입 성공 메시지 표시
                    Toast.makeText(getApplicationContext(), "회원가입 성공!", Toast.LENGTH_SHORT).show();

                    // 회원가입 후 다른 화면으로 이동 등 추가 동작 가능
                }
            }

        });
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtId.setText("");
                txtEmail.setText("");
                txtPw.setText("");
                txtPwc.setText("");
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}



   